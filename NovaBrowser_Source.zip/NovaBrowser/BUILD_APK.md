# Build your APK

## Easiest route: Android Studio
1. Download and install Android Studio on a computer.
2. Open the `android/` directory in this project.
3. Allow Gradle sync and SDK downloads.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The generated debug APK is typically at:
   `android/app/build/outputs/apk/debug/app-debug.apk`

## Project notes
- This is a starter Android WebView browser, not a hardened production browser.
- WebView-based tabs are separate WebView instances.
- Some modern sites may not work exactly like Chrome.
- Test on your own device before sharing the APK.

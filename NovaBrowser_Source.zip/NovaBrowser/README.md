# Nova Browser

A starter Android browser project with:
- Search/address bar
- Multiple native WebView tabs
- Back, forward, reload, home
- Dark/light app theme

## Build APK (free, on a computer)

1. Install Android Studio (includes Android SDK) and a compatible JDK.
2. Open the `android` folder in Android Studio.
3. Let Gradle sync and download dependencies.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location.

This project uses Android WebView. Some websites may restrict embedding or behave differently from Chrome. Use only for lawful browsing. Safe Browsing is enabled where supported.

## Note
This is a starter project, not a Play Store-ready release. Review app permissions, privacy disclosures, security, and testing before distributing it.

package com.novabrowser.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.HorizontalScrollView;
import android.widget.FrameLayout;
import android.net.Uri;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int BG_DARK = Color.rgb(17, 24, 39);
    private static final int PANEL_DARK = Color.rgb(39, 49, 67);
    private static final int BG_LIGHT = Color.rgb(245, 247, 251);
    private static final int PANEL_LIGHT = Color.rgb(226, 232, 240);
    private static final int BLUE = Color.rgb(37, 99, 235);

    private LinearLayout root, topBar, tabBar, controls;
    private FrameLayout webContainer;
    private EditText address;
    private Button themeButton;
    private final List<Tab> tabs = new ArrayList<>();
    private int activeIndex = 0;
    private boolean dark = true;

    private static class Tab {
        WebView web;
        String title = "New Tab";
        String url = "";
        Tab(WebView web) { this.web = web; }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildLayout();
        addTab("https://www.google.com");
    }

    private void buildLayout() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(10), dp(10), dp(10), dp(6));
        setContentView(root);

        topBar = new LinearLayout(this);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = new TextView(this);
        brand.setText("🌐 Nova Browser");
        brand.setTextSize(20);
        brand.setTypeface(null, Typeface.BOLD);
        topBar.addView(brand, new LinearLayout.LayoutParams(0, dp(48), 1));

        themeButton = button("☀ Light");
        themeButton.setOnClickListener(v -> { dark = !dark; applyTheme(); });
        topBar.addView(themeButton);
        root.addView(topBar);

        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        tabBar = new LinearLayout(this);
        tabBar.setOrientation(LinearLayout.HORIZONTAL);
        scroll.addView(tabBar);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, dp(46)));

        controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        Button back = button("‹");
        back.setOnClickListener(v -> { WebView w = currentWeb(); if (w != null && w.canGoBack()) w.goBack(); });
        Button forward = button("›");
        forward.setOnClickListener(v -> { WebView w = currentWeb(); if (w != null && w.canGoForward()) w.goForward(); });
        Button reload = button("↻");
        reload.setOnClickListener(v -> { WebView w = currentWeb(); if (w != null) w.reload(); });
        Button home = button("⌂");
        home.setOnClickListener(v -> navigate("https://www.google.com"));
        controls.addView(back); controls.addView(forward); controls.addView(reload); controls.addView(home);

        address = new EditText(this);
        address.setSingleLine(true);
        address.setTextSize(14);
        address.setHint("Search or enter website");
        address.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        address.setImeOptions(EditorInfo.IME_ACTION_GO);
        address.setPadding(dp(10), 0, dp(8), 0);
        LinearLayout.LayoutParams addressParams = new LinearLayout.LayoutParams(0, dp(44), 1);
        addressParams.setMargins(dp(4), 0, dp(4), 0);
        controls.addView(address, addressParams);
        Button go = button("Go");
        go.setOnClickListener(v -> submitAddress());
        controls.addView(go);
        address.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                submitAddress(); return true;
            }
            return false;
        });
        root.addView(controls);

        Button newTab = button("+ New Tab");
        newTab.setOnClickListener(v -> addTab("https://www.google.com"));
        root.addView(newTab);

        webContainer = new FrameLayout(this);
        LinearLayout.LayoutParams webParams = new LinearLayout.LayoutParams(-1, 0, 1);
        webParams.topMargin = dp(8);
        root.addView(webContainer, webParams);
        applyTheme();
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setPadding(dp(8), 0, dp(8), 0);
        return b;
    }

    private void addTab(String url) {
        WebView web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setSupportMultipleWindows(false);
        settings.setSafeBrowsingEnabled(true);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return false;
            }
            @Override public void onPageFinished(WebView view, String url) {
                int idx = indexOf(view);
                if (idx >= 0) {
                    tabs.get(idx).url = url;
                    String title = view.getTitle();
                    tabs.get(idx).title = (title == null || title.trim().isEmpty()) ? url : title;
                    if (idx == activeIndex) address.setText(url);
                    renderTabs();
                }
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        Tab tab = new Tab(web);
        tabs.add(tab);
        activeIndex = tabs.size() - 1;
        webContainer.removeAllViews();
        webContainer.addView(web, new FrameLayout.LayoutParams(-1, -1));
        web.loadUrl(url);
        renderTabs();
    }

    private int indexOf(WebView web) {
        for (int i = 0; i < tabs.size(); i++) if (tabs.get(i).web == web) return i;
        return -1;
    }

    private WebView currentWeb() {
        return tabs.isEmpty() ? null : tabs.get(activeIndex).web;
    }

    private void submitAddress() {
        String text = address.getText().toString().trim();
        if (text.isEmpty()) return;
        String url;
        if (text.matches("(?i)^(https?://)?[a-z0-9-]+(\\.[a-z0-9-]+)+(\\:[0-9]+)?([/?#].*)?$")) {
            url = text.matches("(?i)^https?://.*") ? text : "https://" + text;
        } else {
            url = "https://www.google.com/search?q=" + Uri.encode(text);
        }
        navigate(url);
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(address.getWindowToken(), 0);
        } catch (Exception ignored) {}
    }

    private void navigate(String url) {
        WebView w = currentWeb();
        if (w != null) w.loadUrl(url);
    }

    private void renderTabs() {
        tabBar.removeAllViews();
        for (int i = 0; i < tabs.size(); i++) {
            final int idx = i;
            LinearLayout item = new LinearLayout(this);
            item.setGravity(Gravity.CENTER_VERTICAL);
            Button select = button(shortTitle(tabs.get(i).title));
            select.setTextColor(i == activeIndex ? BLUE : (dark ? Color.WHITE : Color.BLACK));
            select.setOnClickListener(v -> switchTab(idx));
            item.addView(select);
            Button close = button("×");
            close.setOnClickListener(v -> closeTab(idx));
            item.addView(close);
            tabBar.addView(item);
        }
        Button plus = button("+");
        plus.setOnClickListener(v -> addTab("https://www.google.com"));
        tabBar.addView(plus);
    }

    private String shortTitle(String title) {
        if (title == null || title.trim().isEmpty()) return "Tab";
        return title.length() > 12 ? title.substring(0, 12) + "…" : title;
    }

    private void switchTab(int index) {
        if (index < 0 || index >= tabs.size()) return;
        activeIndex = index;
        webContainer.removeAllViews();
        webContainer.addView(tabs.get(index).web, new FrameLayout.LayoutParams(-1, -1));
        address.setText(tabs.get(index).url);
        renderTabs();
    }

    private void closeTab(int index) {
        if (index < 0 || index >= tabs.size()) return;
        tabs.get(index).web.stopLoading();
        tabs.get(index).web.destroy();
        tabs.remove(index);
        if (tabs.isEmpty()) {
            addTab("https://www.google.com");
            return;
        }
        if (activeIndex >= tabs.size()) activeIndex = tabs.size() - 1;
        else if (index < activeIndex) activeIndex--;
        switchTab(activeIndex);
    }

    private void applyTheme() {
        int bg = dark ? BG_DARK : BG_LIGHT;
        int panel = dark ? PANEL_DARK : PANEL_LIGHT;
        int fg = dark ? Color.WHITE : Color.rgb(17, 24, 39);
        root.setBackgroundColor(bg);
        topBar.setBackgroundColor(bg);
        for (int i = 0; i < topBar.getChildCount(); i++) {
            View v = topBar.getChildAt(i);
            if (v instanceof TextView) ((TextView) v).setTextColor(fg);
        }
        themeButton.setText(dark ? "☀ Light" : "🌙 Dark");
        tabBar.setBackgroundColor(bg);
        controls.setBackgroundColor(bg);
        for (int i = 0; i < controls.getChildCount(); i++) {
            View v = controls.getChildAt(i);
            if (v instanceof Button) {
                v.setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel));
                ((Button) v).setTextColor(fg);
            }
        }
        address.setTextColor(fg);
        address.setHintTextColor(dark ? Color.LTGRAY : Color.GRAY);
        address.setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel));
        renderTabs();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override public void onBackPressed() {
        WebView w = currentWeb();
        if (w != null && w.canGoBack()) w.goBack();
        else super.onBackPressed();
    }
}
